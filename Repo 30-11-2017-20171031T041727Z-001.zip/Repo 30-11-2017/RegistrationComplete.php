<html>
	<head>
		<title>
		Registration completed
        </title>
        <link rel=stylesheet href="signUp.css" type="text/css">
		<link rel=stylesheet href="header.css" type="text/css">
		<link rel=stylesheet href="content.css" type="text/css">
		<link rel=stylesheet href="footer.css" type="text/css">
	</head>
	<body>
	<p>Thank you for registering!</p>
	<button value="Return to Homepage" onclick="<a href='homepage.php'></a>"></button>
	</body>
</html>