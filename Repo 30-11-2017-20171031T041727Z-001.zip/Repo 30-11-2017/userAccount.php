<html>
	<head>
	<title>
		The Ceryx
		</title>
		<link rel=stylesheet href="header.css" type="text/css">
		<link rel=stylesheet href="content.css" type="text/css">
		<link rel=stylesheet href="footer.css" type="text/css">
	
	</head>
	
	<body>
		<!-- Head of the page -->
			<div id="header">
				<?php
					session_start();
					
					if(isset($_SESSION['user_status'])) {
						echo "<a href='check_user.php' alt=''><img src='banner.png'></a>
								<div id='userWelcome'>Welcome, ".$_SESSION['user_name']."<br><br><br>"."
								<ul id='outview'>
								<li><a href='userAccount.php'>View your account</a></li>
								<li><a href='homepage.php'>Log out</a></li>
							</ul></div>";
					}
					else {
						echo "<a href='homepage.php' alt=''><img src='banner.png'></a>
								<ul id='inup'>
								<li><a href='signIn.php'>Sign in</a>
								<li><a href='signUp.php'>Sign up</a>
							</ul>";
					}
				?>
			</div>
			<div>
		This page will represent the user's account page.
		<p><pre>
		
		
		
		
		</pre></p>
		</div>
			<!--About us and Contact us-->
		<div id="footer">
			<ul>
				<li><a href="aboutUs.php">About us</a>
				<li><a href="contactUs.php">Contact us</a>
			</ul>
		</div>
	</body>
</html>